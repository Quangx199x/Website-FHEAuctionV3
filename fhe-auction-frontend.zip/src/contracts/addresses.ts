// src/contracts/addresses.ts

export const AUCTION_CONTRACT_ADDRESS = '0x1cb2bbe021f9f3284fc325773e6eb80090fb520b' as const

export const SEPOLIA_CHAIN_ID = 11155111